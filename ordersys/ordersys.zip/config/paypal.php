<?php
return [
	'credentials' => [
		'username' => 'johniemutio_api1.gmail.com',
		'password' => 'WKANEL9F2HT6ZNVT',
		'signature' => 'A71sJTqpHwwW466qghuL3rOD3SjPAeAiwMJ9oxR1xRc7i20Xu4Vb.8S4',
		'sandbox' => false
	],
];