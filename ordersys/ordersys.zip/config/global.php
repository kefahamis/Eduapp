<?php
/*
Globals
*/

return [
	'site_url' => 'https://www.eddusaver.com'
];
