
<div class="footer-wrapper  js_footer-wrapper">
	<div class="footer__wrapper">
		<div class="row" style="display: block;">
			<div class="footer_top">
				<div class="disclaimer">
					<p class="footer_heading">The service can be used for</p>
					<p>
						Additional insights into the subject with relevant details concerning key questions;<br>
						Strategies for paraphrasing appropriately according to your school's guidelines;<br>
						Proper use of citations in academic writing
					</p>
				</div>
				<div class="site-map">
					<p class="footer_heading">Site map</p>
					<ul>
						<li><a href="{{config('global.site_url')}}">Home</a></li>
						<li><a href="{{config('global.site_url')}}/terms-and-conditions">Terms and Conditions</a></li>
                        <li><a href="{{config('global.site_url')}}/privacy-policy-2">Privacy Policy</a></li>
                        <li><p>Support: +1 (646) (978) 2866</p></li>
                    </ul>
                </div>
                <div class="accept">
                   <p class="footer_heading">Secure Payment with:</p>
                   <img class="" alt="Accepted Cards" src="{{asset('images/paypal tray.png')}}">
                   <div class="clearfix"></div>
                   <ul class="social">
                      <li>
                         <a href="#"><i class="fa fa-facebook"></i></a>
                     </li>
                     <li>
                         <a href="#"><i class="soc-icon tw"></i></a>
                     </li>
                     <li>
                         <a href="#"><i class="soc-icon lin"></i></a>
                     </li>
                 </ul>
             </div>
             <div class="uk-clearfix"></div>
         </div>
     </div>
     <div class="copyrights" style="text-align: center;">
         <div class="row" >
            <p><?php echo date('Y');?> © Eddusaver.Powered By Pafè</p>
        </div>
    </div>
</div>
</div>